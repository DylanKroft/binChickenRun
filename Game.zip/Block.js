export default class Block {
    
    constructor(x, y, img, height, width) {
        this.img = img;
        this.x = x;
        this.y = y;
        this.height = height;
        this.width = width;
        this.x_vec;
    }
}